import { Component, OnInit } from "@angular/core";
import { Contact } from "../../model/contact";

@Component({
  selector: "pb-contact-details",
  templateUrl: "./contact-details.component.html",
  styleUrls: ["./contact-details.component.css"]
})
export class ContactDetailsComponent implements OnInit {
  contact: Contact;
  constructor() {}

  ngOnInit() {}
}
